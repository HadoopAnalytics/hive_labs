public class ReadHiveEventProto {
}

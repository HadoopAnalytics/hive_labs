# HiveServer2JDBCSample
build using 
mvn package

and run as
java -jar HiveServer2JDBCTest-jar-with-dependencies.jar connection_string userid password
